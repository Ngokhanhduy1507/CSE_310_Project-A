package com.example.Hotel.Config;

public class SecurityConfig {

}
