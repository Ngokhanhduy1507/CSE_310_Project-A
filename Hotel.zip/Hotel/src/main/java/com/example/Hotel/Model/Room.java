package com.example.Hotel.Model;

public class Room {

}
