package com.example.Hotel.Model;

public class Guest {

}
