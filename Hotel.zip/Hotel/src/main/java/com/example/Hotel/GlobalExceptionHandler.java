package com.example.Hotel;

public class GlobalExceptionHandler {

}
