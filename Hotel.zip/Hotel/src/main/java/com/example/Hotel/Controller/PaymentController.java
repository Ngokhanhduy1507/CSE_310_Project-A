package com.example.Hotel.Controller;

public class PaymentController {

}
