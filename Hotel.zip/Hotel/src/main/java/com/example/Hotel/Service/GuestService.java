package com.example.Hotel.Service;

public class GuestService {

}
