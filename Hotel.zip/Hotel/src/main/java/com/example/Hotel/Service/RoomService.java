package com.example.Hotel.Service;

public class RoomService {

}
