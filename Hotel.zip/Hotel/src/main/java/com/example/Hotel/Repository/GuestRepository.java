package com.example.Hotel.Repository;

public interface GuestRepository {

}
