package com.example.Hotel.Repository;

public interface HotelRepository {

}
