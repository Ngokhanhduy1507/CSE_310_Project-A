package com.example.Hotel.Repository;

public interface BookingRepository {

}
